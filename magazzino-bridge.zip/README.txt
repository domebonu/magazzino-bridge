MAGAZZINO-BRIDGE - ISTRUZIONI UPLOAD GITHUB

1️⃣ Vai su https://github.com e apri il repository 'magazzino-bridge'
2️⃣ Clicca su 'Add file' → 'Upload files'
3️⃣ Trascina dentro i file estratti da questo ZIP:
   - bridge.php
   - magazzino_web.html
   - magazzino_web_code.txt (opzionale)
4️⃣ Scorri in basso e clicca su 'Commit changes'
5️⃣ Render aggiornerà automaticamente il sito in pochi secondi.

🔗 Link per accedere al tuo magazzino:
   https://magazzino-bridge.onrender.com/magazzino_web.html

SICUREZZA:
Solo l'account domebonu@gmail.com può modificare le quantità.
Gli altri utenti potranno soltanto consultare i dati.

Per aggiornare in futuro:
- Modifica il file 'magazzino_web.html' e ricaricalo nello stesso modo.
